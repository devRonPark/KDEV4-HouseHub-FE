// 페이지네이션 DTO
export interface PaginationDto {
  totalPages: number;
  totalElements: number;
  size: number;
  currentPage: number;
}
